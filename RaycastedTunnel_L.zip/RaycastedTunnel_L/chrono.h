
unsigned int GetMsTime();

float ChronoWatchReset();
